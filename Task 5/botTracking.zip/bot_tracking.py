import numpy as np
import cv2
from trackBot import *
cap=cv2.VideoCapture(1)
x=int(raw_input("x"))
y=int(raw_input("y"))
botX=1000
boty=1000
while abs(botX-x)>50 or abs(botY-y)>50 or abs(diff)>=20:
	ret,frame=cap.read()
	pos=trackBot(frame,x,y)
	botX=int(pos[0])
	botY=int(pos[1])
	#print botX,botY
	target_angle=orient([x,y],[botX,botY])
	diff=pos[2]-target_angle
	#print pos[2],target_angle,diff
	l=[]
	while abs(diff)>=18:
		if abs(diff)<=180:
			if diff>0:
				print pos[2],target_angle,'rotate',abs(diff),'left',botX-x, botY-y
				rotate('a')
			elif diff<0:
				print pos[2],target_angle,'rotate',abs(diff),'right',botX-x, botY-y
				rotate('d')
			#else:
				#print 'dont rotate'
		else:
			if diff>0:
				print pos[2],target_angle,'rotate',abs(360-diff),'right',botX-x, botY-y
				rotate('d')
			elif diff<0:
				print pos[2],target_angle,'rotate',abs(diff+360),'left',botX-x, botY-y
				rotate('a')
		cv2.waitKey(250)

		ret,frame=cap.read()
		pos=trackBot(frame,x,y)
		botX=int(pos[0])
		botY=int(pos[1])
		#print botX,botY
		target_angle=orient([x,y],[botX,botY])
		diff=pos[2]-target_angle
		#print pos[2]

	sendByte('w')
	if cv2.waitKey(250)==27:
		break
		'''
while abs(pos[2])>5:
	if abs(pos[2])<90 and pos[2]<0:
		rotate('a')
	pos=trackBot(frame,x,y)
	ret,frame=cap.read()
	if cv2.waitKey(250)==27:
		break
		'''
cap.release()
cv2.destroyAllWindows()
